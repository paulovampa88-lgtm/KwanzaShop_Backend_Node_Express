
// Puppeteer automation skeleton (disabled). Implement on a dedicated server if required.
module.exports = {
  async createOrderOnAliExpress() {
    throw new Error('Puppeteer automation not enabled. Implement on server.');
  }
};
